<div class="tableroBox">
        <div class="tablero">
            <div class="casillaB">
                <?php
                    if ($tablero->casillas["1" . "8"]->ocupado) {
                        if (strcmp($tablero->casillas["1" . "8"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["1" . "8"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--18-->
            <div class="casillaN">
                <?php
                    if ($tablero->casillas["2" . "8"]->ocupado) {
                        if (strcmp($tablero->casillas["2" . "8"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["2" . "8"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--28-->
            <div class="casillaB">
                <?php
                    if ($tablero->casillas["3" . "8"]->ocupado) {
                        if (strcmp($tablero->casillas["3" . "8"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["3" . "8"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--38-->
            <div class="casillaN">
                <?php
                    if ($tablero->casillas["4" . "8"]->ocupado) {
                        if (strcmp($tablero->casillas["4" . "8"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["4" . "8"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--48-->
            <div class="casillaB">
                <?php
                    if ($tablero->casillas["5" . "8"]->ocupado) {
                        if (strcmp($tablero->casillas["5" . "8"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["5" . "8"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--58-->
            <div class="casillaN">
                <?php
                    if ($tablero->casillas["6" . "8"]->ocupado) {
                        if (strcmp($tablero->casillas["6" . "8"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["6" . "8"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--68-->
            <div class="casillaB">
                <?php
                    if ($tablero->casillas["7" . "8"]->ocupado) {
                        if (strcmp($tablero->casillas["7" . "8"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["7" . "8"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--78-->
            <div class="casillaN">
                <?php
                    if ($tablero->casillas["8" . "8"]->ocupado) {
                        if (strcmp($tablero->casillas["8" . "8"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["8" . "8"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--88-->
            <div class="casillaN">
                <?php
                    if ($tablero->casillas["1" . "7"]->ocupado) {
                        if (strcmp($tablero->casillas["1" . "7"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["1" . "7"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--17-->
            <div class="casillaB">
                <?php
                    if ($tablero->casillas["2" . "7"]->ocupado) {
                        if (strcmp($tablero->casillas["2" . "7"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["2" . "7"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--27-->
            <div class="casillaN">
                <?php
                    if ($tablero->casillas["3" . "7"]->ocupado) {
                        if (strcmp($tablero->casillas["3" . "7"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["3" . "7"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--37-->
            <div class="casillaB">
                <?php
                    if ($tablero->casillas["4" . "7"]->ocupado) {
                        if (strcmp($tablero->casillas["4" . "7"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["4" . "7"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--47-->
            <div class="casillaN">
                <?php
                    if ($tablero->casillas["5" . "7"]->ocupado) {
                        if (strcmp($tablero->casillas["5" . "7"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["5" . "7"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--57-->
            <div class="casillaB">
                <?php
                    if ($tablero->casillas["6" . "7"]->ocupado) {
                        if (strcmp($tablero->casillas["6" . "7"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["6" . "7"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--67-->
            <div class="casillaN">
                <?php
                    if ($tablero->casillas["7" . "7"]->ocupado) {
                        if (strcmp($tablero->casillas["7" . "7"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["7" . "7"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--77-->
            <div class="casillaB">
                <?php
                    if ($tablero->casillas["8" . "7"]->ocupado) {
                        if (strcmp($tablero->casillas["8" . "7"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["8" . "7"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--87-->
            <div class="casillaB">
                <?php
                    if ($tablero->casillas["1" . "6"]->ocupado) {
                        if (strcmp($tablero->casillas["1" . "6"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["1" . "6"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--16-->
            <div class="casillaN">
                <?php
                    if ($tablero->casillas["2" . "6"]->ocupado) {
                        if (strcmp($tablero->casillas["2" . "6"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["2" . "6"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--26-->
            <div class="casillaB">
                <?php
                    if ($tablero->casillas["3" . "6"]->ocupado) {
                        if (strcmp($tablero->casillas["3" . "6"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["3" . "6"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--36-->
            <div class="casillaN">
                <?php
                    if ($tablero->casillas["4" . "6"]->ocupado) {
                        if (strcmp($tablero->casillas["4" . "6"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["4" . "6"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--46-->
            <div class="casillaB">
                <?php
                    if ($tablero->casillas["5" . "6"]->ocupado) {
                        if (strcmp($tablero->casillas["5" . "6"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["5" . "6"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--56-->
            <div class="casillaN">
                <?php
                    if ($tablero->casillas["6" . "6"]->ocupado) {
                        if (strcmp($tablero->casillas["6" . "6"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["6" . "6"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--66-->
            <div class="casillaB">
                <?php
                    if ($tablero->casillas["7" . "6"]->ocupado) {
                        if (strcmp($tablero->casillas["7" . "6"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["7" . "6"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--76-->
            <div class="casillaN">
                <?php
                    if ($tablero->casillas["8" . "6"]->ocupado) {
                        if (strcmp($tablero->casillas["8" . "6"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["8" . "6"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--86-->
            <div class="casillaN">
                <?php
                    if ($tablero->casillas["1" . "5"]->ocupado) {
                        if (strcmp($tablero->casillas["1" . "5"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["1" . "5"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--15-->
            <div class="casillaB">
                <?php
                    if ($tablero->casillas["2" . "5"]->ocupado) {
                        if (strcmp($tablero->casillas["2" . "5"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["2" . "5"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--25-->
            <div class="casillaN">
                <?php
                    if ($tablero->casillas["3" . "5"]->ocupado) {
                        if (strcmp($tablero->casillas["3" . "5"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["3" . "5"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--35-->
            <div class="casillaB">
                <?php
                    if ($tablero->casillas["4" . "5"]->ocupado) {
                        if (strcmp($tablero->casillas["4" . "5"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["4" . "5"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--45-->
            <div class="casillaN">
                <?php
                    if ($tablero->casillas["5" . "5"]->ocupado) {
                        if (strcmp($tablero->casillas["5" . "5"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["5" . "5"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--55-->
            <div class="casillaB">
                <?php
                    if ($tablero->casillas["6" . "5"]->ocupado) {
                        if (strcmp($tablero->casillas["6" . "5"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["6" . "5"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--65-->
            <div class="casillaN">
                <?php
                    if ($tablero->casillas["7" . "5"]->ocupado) {
                        if (strcmp($tablero->casillas["7" . "5"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["7" . "5"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--75-->
            <div class="casillaB">
                <?php
                    if ($tablero->casillas["8" . "5"]->ocupado) {
                        if (strcmp($tablero->casillas["8" . "5"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["8" . "5"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--85-->
            <div class="casillaB">
                <?php
                    if ($tablero->casillas["1" . "4"]->ocupado) {
                        if (strcmp($tablero->casillas["1" . "4"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["1" . "4"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--14-->
            <div class="casillaN">
                <?php
                    if ($tablero->casillas["2" . "4"]->ocupado) {
                        if (strcmp($tablero->casillas["2" . "4"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["2" . "4"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--24-->
            <div class="casillaB">
                <?php
                    if ($tablero->casillas["3" . "4"]->ocupado) {
                        if (strcmp($tablero->casillas["3" . "4"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["3" . "4"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--34-->
            <div class="casillaN">
                <?php
                    if ($tablero->casillas["4" . "4"]->ocupado) {
                        if (strcmp($tablero->casillas["4" . "4"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["4" . "4"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--44--> 
            <div class="casillaB">
                <?php
                    if ($tablero->casillas["5" . "4"]->ocupado) {
                        if (strcmp($tablero->casillas["5" . "4"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["5" . "4"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--54-->
            <div class="casillaN">
                <?php
                    if ($tablero->casillas["6" . "4"]->ocupado) {
                        if (strcmp($tablero->casillas["6" . "4"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["6" . "4"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--64-->
            <div class="casillaB">
                <?php
                    if ($tablero->casillas["7" . "4"]->ocupado) {
                        if (strcmp($tablero->casillas["7" . "4"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["7" . "4"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--74-->
            <div class="casillaN">
                <?php
                    if ($tablero->casillas["8" . "4"]->ocupado) {
                        if (strcmp($tablero->casillas["8" . "4"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["8" . "4"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--84-->
            <div class="casillaN">
                <?php
                    if ($tablero->casillas["1" . "3"]->ocupado) {
                        if (strcmp($tablero->casillas["1" . "3"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["1" . "3"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--13-->
            <div class="casillaB">
                <?php
                    if ($tablero->casillas["2" . "3"]->ocupado) {
                        if (strcmp($tablero->casillas["2" . "3"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["2" . "3"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--23-->
            <div class="casillaN">
                <?php
                    if ($tablero->casillas["3" . "3"]->ocupado) {
                        if (strcmp($tablero->casillas["3" . "3"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["3" . "3"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--33-->
            <div class="casillaB">
                <?php
                    if ($tablero->casillas["4" . "3"]->ocupado) {
                        if (strcmp($tablero->casillas["4" . "3"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["4" . "3"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--43-->
            <div class="casillaN">
                <?php
                    if ($tablero->casillas["5" . "3"]->ocupado) {
                        if (strcmp($tablero->casillas["5" . "3"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["5" . "3"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--53-->
            <div class="casillaB">
                <?php
                    if ($tablero->casillas["6" . "3"]->ocupado) {
                        if (strcmp($tablero->casillas["6" . "3"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["6" . "3"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--63-->
            <div class="casillaN">
                <?php
                    if ($tablero->casillas["7" . "3"]->ocupado) {
                        if (strcmp($tablero->casillas["7" . "3"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["7" . "3"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--73-->
            <div class="casillaB">
                <?php
                    if ($tablero->casillas["8" . "3"]->ocupado) {
                        if (strcmp($tablero->casillas["8" . "3"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["8" . "3"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--83-->
            <div class="casillaB">
                <?php
                    if ($tablero->casillas["1" . "2"]->ocupado) {
                        if (strcmp($tablero->casillas["1" . "2"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["1" . "2"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--12-->
            <div class="casillaN">
                <?php
                    if ($tablero->casillas["2" . "2"]->ocupado) {
                        if (strcmp($tablero->casillas["2" . "2"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["2" . "2"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--22-->
            <div class="casillaB">
                <?php
                    if ($tablero->casillas["3" . "2"]->ocupado) {
                        if (strcmp($tablero->casillas["3" . "2"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["3" . "2"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--32-->
            <div class="casillaN">
                <?php
                    if ($tablero->casillas["4" . "2"]->ocupado) {
                        if (strcmp($tablero->casillas["4" . "2"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["4" . "2"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--42-->
            <div class="casillaB">
                <?php
                    if ($tablero->casillas["5" . "2"]->ocupado) {
                        if (strcmp($tablero->casillas["5" . "2"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["5" . "2"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--52-->
            <div class="casillaN">
                <?php
                    if ($tablero->casillas["6" . "2"]->ocupado) {
                        if (strcmp($tablero->casillas["6" . "2"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["6" . "2"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--62-->
            <div class="casillaB">
                <?php
                    if ($tablero->casillas["7" . "2"]->ocupado) {
                        if (strcmp($tablero->casillas["7" . "2"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["7" . "2"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--72-->
            <div class="casillaN">
                <?php
                    if ($tablero->casillas["8" . "2"]->ocupado) {
                        if (strcmp($tablero->casillas["8" . "2"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["8" . "2"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--82-->
            <div class="casillaN">
                <?php
                    if ($tablero->casillas["1" . "1"]->ocupado) {
                        if (strcmp($tablero->casillas["1" . "1"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["1" . "1"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--11-->
            <div class="casillaB">
                <?php
                    if ($tablero->casillas["2" . "1"]->ocupado) {
                        if (strcmp($tablero->casillas["2" . "1"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["2" . "1"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--21-->
            <div class="casillaN">
                <?php
                    if ($tablero->casillas["3" . "1"]->ocupado) {
                        if (strcmp($tablero->casillas["3" . "1"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["3" . "1"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--31-->
            <div class="casillaB">
                <?php
                    if ($tablero->casillas["4" . "1"]->ocupado) {
                        if (strcmp($tablero->casillas["4" . "1"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["4" . "1"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--41-->
            <div class="casillaN">
                <?php
                    if ($tablero->casillas["5" . "1"]->ocupado) {
                        if (strcmp($tablero->casillas["5" . "1"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["5" . "1"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--51-->
            <div class="casillaB">
                <?php
                    if ($tablero->casillas["6" . "1"]->ocupado) {
                        if (strcmp($tablero->casillas["6" . "1"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["6" . "1"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>  
            </div> <!--61-->
            <div class="casillaN">
                <?php
                    if ($tablero->casillas["7" . "1"]->ocupado) {
                        if (strcmp($tablero->casillas["7" . "1"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["7" . "1"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--71-->
            <div class="casillaB">
                <?php
                    if ($tablero->casillas["8" . "1"]->ocupado) {
                        if (strcmp($tablero->casillas["8" . "1"]->ficha->color, "blanco") === 0) {
                ?>
                    <img src="<?php echo $fichaB?>" alt="">
                <?php
                        }
                        if (strcmp($tablero->casillas["8" . "1"]->ficha->color, "negro") === 0) {
                ?>
                        <img src="<?php echo $fichaN?>" alt="">
                <?php
                        }
                    }
                ?>
            </div> <!--81-->
        </div>
    </div>